<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Quienes somos</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous" type="text/css">
</head>

<body>

<?php include("cabecera.php") ?>
<div class="container">
		<div class="col-sm-4 col-md-4">
		<h2>Quienes Somos</h2>
	</div>
		<br />
		<fieldset title="Quienes somos" style="text-align:center">
			<h4 style="font-family:Constantia,Lucida Bright,DejaVu Serif,Georgia,serif">
  				Somos una empresa formada por un grupo de compa�eros de la facultad, que se encarga de la venta de discos de una gran variedad de artistas y de la distrbucion de los mismos dentro de todo nuestro pais, contribuyendo con una Argentina mas conectada.
			</h4>
		</fieldset>
	</div>
<?php include("modal.php"); ?>
</div>
<?php include("pie.php"); ?>


</body>
</html>
